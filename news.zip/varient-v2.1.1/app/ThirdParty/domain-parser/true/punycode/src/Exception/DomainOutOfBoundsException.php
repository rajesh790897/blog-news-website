<?php

namespace TrueBV\Exception;

/**
 * Class DomainOutOfBoundsException
 * @package TrueBV\Exception
 * @author  Sebastian Kroczek <sk@xbug.de>
 */
class DomainOutOfBoundsException extends OutOfBoundsException
{

}
